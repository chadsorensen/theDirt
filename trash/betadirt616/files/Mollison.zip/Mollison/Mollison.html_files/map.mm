<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1146182419339" ID="Freemind_Link_797096311" MODIFIED="1265958428834">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Mollison's Bioregional Organization
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1146182456182" FOLDED="true" ID="_" MODIFIED="1265958318942" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Food &amp; Food Support systems
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146182477042" FOLDED="true" ID="Freemind_Link_1668994712" MODIFIED="1197607775815" TEXT="Plant resources">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146183465774" FOLDED="true" ID="Freemind_Link_633385486" MODIFIED="1244915764859" TEXT="nurseries &amp; propigation centers">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183479043" ID="Freemind_Link_1771829346" MODIFIED="1146183546620" TEXT="tissue culture">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1146183501375" ID="Freemind_Link_1855626243" MODIFIED="1146183546630" TEXT="source of innoculants">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1146183509076" ID="Freemind_Link_1536904029" MODIFIED="1146183546640" TEXT="mycorrhiza">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1146183552028" FOLDED="true" ID="Freemind_Link_1354418515" MODIFIED="1244915764859" TEXT="plant collections">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183555693" ID="Freemind_Link_1812828935" MODIFIED="1146183562002" TEXT="botanical gardens"/>
<node COLOR="#111111" CREATED="1146183562403" ID="Freemind_Link_1096403450" MODIFIED="1146183570194" TEXT="economic plant assemblies"/>
<node COLOR="#111111" CREATED="1146183570484" ID="Freemind_Link_735474887" MODIFIED="1146183575351" TEXT="aquatics"/>
</node>
<node COLOR="#990000" CREATED="1146183577264" FOLDED="true" ID="Freemind_Link_799067841" MODIFIED="1244915764859" TEXT="research institutes">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183619535" ID="Freemind_Link_654636608" MODIFIED="1146183622609" TEXT="general"/>
<node COLOR="#111111" CREATED="1146183596822" ID="Freemind_Link_869454293" MODIFIED="1146183609831" TEXT="horticultural"/>
<node COLOR="#111111" CREATED="1146183610351" ID="Freemind_Link_1940162037" MODIFIED="1146183618553" TEXT="pastoral"/>
</node>
<node COLOR="#990000" CREATED="1146183626615" ID="Freemind_Link_1956304705" MODIFIED="1146183636169" TEXT="seed sources &amp; exchange">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146183639654" ID="Freemind_Link_606944777" MODIFIED="1146183663848" TEXT="native species reserves &amp; nurseries">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146183668405" FOLDED="true" ID="Freemind_Link_1071095770" MODIFIED="1244915764859" TEXT="demonstration">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183701523" ID="Freemind_Link_472481886" MODIFIED="1146183702834" TEXT="farms"/>
<node COLOR="#111111" CREATED="1146183703285" ID="Freemind_Link_1080790675" MODIFIED="1146183704747" TEXT="gardens"/>
<node COLOR="#111111" CREATED="1146183705608" ID="Freemind_Link_1248078289" MODIFIED="1146183706420" TEXT=" teaching centers"/>
<node COLOR="#111111" CREATED="1146183709835" ID="Freemind_Link_222152986" MODIFIED="1146183715663" TEXT="worksop converers"/>
</node>
<node COLOR="#990000" CREATED="1146183731005" FOLDED="true" ID="Freemind_Link_1419984121" MODIFIED="1244915764859" TEXT="government departments ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183738656" ID="Freemind_Link_529016062" MODIFIED="1146183743353" TEXT="their resources"/>
<node COLOR="#111111" CREATED="1146183745416" ID="Freemind_Link_981071723" MODIFIED="1146183749351" TEXT="regulations"/>
</node>
<node COLOR="#990000" CREATED="1146183782739" FOLDED="true" ID="Freemind_Link_1674098066" MODIFIED="1244915764859" TEXT="volunteer agencies for plant">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183814665" ID="Freemind_Link_1663941282" MODIFIED="1146183831900" TEXT="protection"/>
<node COLOR="#111111" CREATED="1146183832751" ID="Freemind_Link_509471236" MODIFIED="1146183835385" TEXT="planting"/>
<node COLOR="#111111" CREATED="1146183835665" ID="Freemind_Link_1678930653" MODIFIED="1146183838429" TEXT="propgation"/>
</node>
<node COLOR="#990000" CREATED="1146183842385" ID="Freemind_Link_48875277" MODIFIED="1146183859520" TEXT="skilled people, botanists, horticulturists">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146183863816" FOLDED="true" ID="Freemind_Link_662022906" MODIFIED="1244915764860" TEXT="references">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183884225" ID="Freemind_Link_798773094" MODIFIED="1146183887240" TEXT="publications"/>
<node COLOR="#111111" CREATED="1146183887740" ID="Freemind_Link_986277526" MODIFIED="1146183894109" TEXT="leaflets"/>
<node COLOR="#111111" CREATED="1146183894350" ID="Freemind_Link_479051998" MODIFIED="1146183902812" TEXT="books"/>
<node COLOR="#111111" CREATED="1146183903092" ID="Freemind_Link_1568564500" MODIFIED="1146183904524" TEXT="posters"/>
</node>
<node COLOR="#990000" CREATED="1146183906447" FOLDED="true" ID="Freemind_Link_1479297822" MODIFIED="1244915764860" TEXT="contractors &amp; consultancy groups">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183920087" ID="Freemind_Link_536427127" MODIFIED="1146183927437" TEXT="implementation of plant systems"/>
<node COLOR="#111111" CREATED="1146183932885" ID="Freemind_Link_624155818" MODIFIED="1146183937001" TEXT="farm design"/>
</node>
<node COLOR="#990000" CREATED="1146183941928" FOLDED="true" ID="Freemind_Link_1640714328" MODIFIED="1244915764860" TEXT="checklist of vegetables, fruits &amp; nuts">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183953855" ID="Freemind_Link_1146182343" MODIFIED="1146183961286" TEXT="that can be grown in the region"/>
<node COLOR="#111111" CREATED="1146183966283" ID="Freemind_Link_1755784423" MODIFIED="1146183989276" TEXT="any special uses other then food provisions"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182480457" FOLDED="true" ID="Freemind_Link_1744091936" MODIFIED="1197607775822" TEXT="Animal resources">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146184010978" FOLDED="true" ID="Freemind_Link_419392763" MODIFIED="1244915764860" TEXT="breeding">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184025739" ID="Freemind_Link_1775782068" MODIFIED="1146184033230" TEXT="breeders"/>
<node COLOR="#111111" CREATED="1146184033450" ID="Freemind_Link_1713303996" MODIFIED="1146184041171" TEXT="stud/propagation centers"/>
<node COLOR="#111111" CREATED="1146184041732" ID="Freemind_Link_1774854328" MODIFIED="1146184049203" TEXT="artificial insemination"/>
<node COLOR="#111111" CREATED="1146184049483" ID="Freemind_Link_1311211760" MODIFIED="1146184053889" TEXT="hatcheries"/>
<node COLOR="#111111" CREATED="1146184089931" ID="Freemind_Link_198641317" MODIFIED="1146184101448" TEXT="aqucultures"/>
</node>
<node COLOR="#990000" CREATED="1146184063413" FOLDED="true" ID="Freemind_Link_1548238542" MODIFIED="1244915764860" TEXT="species collections">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184067218" ID="Freemind_Link_831773607" MODIFIED="1146184078224" TEXT="including worms and invertebrates"/>
</node>
<node COLOR="#990000" CREATED="1146184122348" FOLDED="true" ID="Freemind_Link_267307000" MODIFIED="1244915764861" TEXT="native species">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184161614" ID="Freemind_Link_893098355" MODIFIED="1146184163807" TEXT="collections"/>
<node COLOR="#111111" CREATED="1146184164058" ID="Freemind_Link_741948793" MODIFIED="1146184169676" TEXT="reserves"/>
<node COLOR="#111111" CREATED="1146184170056" ID="Freemind_Link_177194179" MODIFIED="1146184175754" TEXT="potential for cultivation"/>
</node>
<node COLOR="#990000" CREATED="1146184243362" FOLDED="true" ID="Freemind_Link_1208088668" MODIFIED="1244915764861" TEXT="demostration">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184245985" ID="Freemind_Link_1344405803" MODIFIED="1146184252285" TEXT="farms"/>
<node COLOR="#111111" CREATED="1146184254738" ID="Freemind_Link_1981137459" MODIFIED="1146184258493" TEXT="free range"/>
<node COLOR="#111111" CREATED="1146184258724" ID="Freemind_Link_942520833" MODIFIED="1146184265043" TEXT="bee culture"/>
<node COLOR="#111111" CREATED="1146184265323" ID="Freemind_Link_1013613117" MODIFIED="1146184281857" TEXT="workshop converners"/>
<node COLOR="#111111" CREATED="1146184282127" ID="Freemind_Link_1571007740" MODIFIED="1146184284611" TEXT="teaching centers"/>
</node>
<node COLOR="#990000" CREATED="1146184315125" FOLDED="true" ID="Freemind_Link_947861099" MODIFIED="1244915764861" TEXT="skilled people">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184317639" ID="Freemind_Link_586082287" MODIFIED="1146184327342" TEXT="farriers"/>
<node COLOR="#111111" CREATED="1146184327803" ID="Freemind_Link_1105688558" MODIFIED="1146184328785" TEXT="vets"/>
<node COLOR="#111111" CREATED="1146184329275" ID="Freemind_Link_720810997" MODIFIED="1146184333932" TEXT="natural historians"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182504892" FOLDED="true" ID="Freemind_Link_1011437638" MODIFIED="1248498868910">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Integrated pest management (IPM)
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146184916379" FOLDED="true" ID="Freemind_Link_1801636553" MODIFIED="1146184950649" TEXT="breeders &amp; suppliers of">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184925833" ID="Freemind_Link_1132387998" MODIFIED="1146184929749" TEXT="insectaries"/>
<node COLOR="#111111" CREATED="1146184930009" ID="Freemind_Link_1877696246" MODIFIED="1146185045049" TEXT="invertebrates predators"/>
<node COLOR="#111111" CREATED="1146185030357" ID="Freemind_Link_1399665063" MODIFIED="1146185037538" TEXT="biological controls"/>
</node>
<node COLOR="#990000" CREATED="1146184894818" ID="Freemind_Link_725922951" MODIFIED="1146184903050" TEXT="management of stored grains and foods">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146184755408" ID="Freemind_Link_1617555048" MODIFIED="1146184768066" TEXT="reference materials">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146184769709" FOLDED="true" ID="Freemind_Link_1571499937" MODIFIED="1244915764861" TEXT="checklist of common">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146184780644" ID="Freemind_Link_960262216" MODIFIED="1146184781866" TEXT="pests"/>
<node COLOR="#111111" CREATED="1146184782247" ID="Freemind_Link_329318996" MODIFIED="1146184785411" TEXT="predators"/>
<node COLOR="#111111" CREATED="1146184785762" ID="Freemind_Link_1341635553" MODIFIED="1146184792922" TEXT="safe control procedures"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182515047" FOLDED="true" ID="Freemind_Link_1070222605" MODIFIED="1248498877391">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Processing &amp; Food preservation
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146185065208" ID="Freemind_Link_1541554600" MODIFIED="1146185074711" TEXT="equipment suppliers">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185075763" ID="Freemind_Link_998843728" MODIFIED="1146185080640" TEXT="food processing centers">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185088481" FOLDED="true" ID="Freemind_Link_509257721" MODIFIED="1244915764861" TEXT="reference">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146185090474" ID="Freemind_Link_1363778700" MODIFIED="1146185100258" TEXT="processing"/>
<node COLOR="#111111" CREATED="1146185100528" ID="Freemind_Link_72118724" MODIFIED="1146185104694" TEXT="preservation"/>
</node>
<node COLOR="#990000" CREATED="1146185106076" FOLDED="true" ID="Freemind_Link_841431000" MODIFIED="1146185141287" TEXT="breeders and suppliers of fermental">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146185114138" ID="Freemind_Link_1246584217" MODIFIED="1146185117082" TEXT="yeasts"/>
<node COLOR="#111111" CREATED="1146185117423" ID="Freemind_Link_13773244" MODIFIED="1146185146985" TEXT="bacteria"/>
<node COLOR="#111111" CREATED="1146185147326" ID="Freemind_Link_1289373609" MODIFIED="1146185150380" TEXT="algal"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182573020" FOLDED="true" ID="Freemind_Link_188706770" MODIFIED="1197607775830" TEXT="markets and outlets">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146185184799" ID="Freemind_Link_794641932" MODIFIED="1146185187263" TEXT="local markets">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185187563" ID="Freemind_Link_718093523" MODIFIED="1146185191649" TEXT="delivery services">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185192851" ID="Freemind_Link_1774186111" MODIFIED="1146185200973" TEXT="export markets &amp; wholesalers">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185201453" ID="Freemind_Link_1612121181" MODIFIED="1146185232097" TEXT="Urban - Rural coop &amp; marketing systems">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185236344" ID="Freemind_Link_252274786" MODIFIED="1146185290832" TEXT="packaging suppiers">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182578358" FOLDED="true" ID="Freemind_Link_214924958" MODIFIED="1197607775831" TEXT="support services &amp; prodcuts for food production">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146185388683" FOLDED="true" ID="Freemind_Link_321765951" MODIFIED="1146185438965" TEXT="food testing services">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146185395252" ID="Freemind_Link_1208925074" MODIFIED="1146185402903" TEXT="residue of biocides"/>
<node COLOR="#111111" CREATED="1146185403334" ID="Freemind_Link_542159497" MODIFIED="1146185415541" TEXT="nutrient, mneral and vitamin content"/>
</node>
<node COLOR="#990000" CREATED="1146185439416" FOLDED="true" ID="Freemind_Link_966147667" MODIFIED="1146185715232" TEXT="soil, water &amp; leaf testing services">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146185454317" ID="Freemind_Link_1694424372" MODIFIED="1146185675996" TEXT="soil micronutrients"/>
<node COLOR="#111111" CREATED="1146185461948" ID="Freemind_Link_133725216" MODIFIED="1146185465123" TEXT="soil additives"/>
<node COLOR="#111111" CREATED="1146185638392" ID="Freemind_Link_563331410" MODIFIED="1146186044946" TEXT="microorganism food web"/>
<node COLOR="#111111" CREATED="1146185476419" ID="Freemind_Link_677004613" MODIFIED="1146185479854" TEXT="pH levels"/>
<node COLOR="#111111" CREATED="1146185492332" FOLDED="true" ID="Freemind_Link_1689776743" MODIFIED="1244915764861" TEXT="contamination">
<node COLOR="#111111" CREATED="1146185480385" ID="Freemind_Link_1160573198" MODIFIED="1146185486293" TEXT="heavy metals"/>
<node COLOR="#111111" CREATED="1146185505761" ID="Freemind_Link_85059256" MODIFIED="1146185593667" TEXT="biocides"/>
<node COLOR="#111111" CREATED="1146185596351" ID="Freemind_Link_1395120161" MODIFIED="1146185610462" TEXT="general toxins"/>
</node>
</node>
<node COLOR="#990000" CREATED="1146185781077" ID="Freemind_Link_1560679304" MODIFIED="1146185800735" TEXT="water supply structures">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185809137" ID="Freemind_Link_801012463" MODIFIED="1146185835185" TEXT="fencing, trellsing &amp; cattle gates">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146185881511" FOLDED="true" ID="Freemind_Link_1663094366" MODIFIED="1146185899557" TEXT="farm &amp; garden machinery">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146185900028" ID="Freemind_Link_130942703" MODIFIED="1146185906347" TEXT="manufacturing"/>
<node COLOR="#111111" CREATED="1146185906587" ID="Freemind_Link_1170228013" MODIFIED="1146185914429" TEXT="testing"/>
<node COLOR="#111111" CREATED="1146185914809" ID="Freemind_Link_1403474274" MODIFIED="1146185924473" TEXT="design"/>
<node COLOR="#111111" CREATED="1146185924743" ID="Freemind_Link_98571069" MODIFIED="1146185928028" TEXT="repair services"/>
<node COLOR="#111111" CREATED="1146185931904" ID="Freemind_Link_1535523455" MODIFIED="1146185942699" TEXT="hire &amp; contract services"/>
</node>
<node COLOR="#990000" CREATED="1146185992871" ID="Freemind_Link_1339308246" MODIFIED="1146185998019" TEXT="land planning services">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186000953" FOLDED="true" ID="Freemind_Link_1246234646" MODIFIED="1146186056773" TEXT="glasshouse, shadehouse, food dryers">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146186057244" ID="Freemind_Link_168521561" MODIFIED="1146186059768" TEXT="builders"/>
<node COLOR="#111111" CREATED="1146186060138" ID="Freemind_Link_1993232218" MODIFIED="1146186062712" TEXT="suppliers"/>
<node COLOR="#111111" CREATED="1146186063132" ID="Freemind_Link_800016566" MODIFIED="1146186067669" TEXT="repair services"/>
</node>
<node COLOR="#990000" CREATED="1146186154043" FOLDED="true" ID="Freemind_Link_1554569064" MODIFIED="1146186172329" TEXT="soil suppliment suppliers">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146186172650" ID="Freemind_Link_383891790" MODIFIED="1146186180671" TEXT="lime quarries"/>
<node COLOR="#111111" CREATED="1146186181002" ID="Freemind_Link_646105422" MODIFIED="1146186183676" TEXT="stone dust"/>
<node COLOR="#111111" CREATED="1146186186720" ID="Freemind_Link_1650477493" MODIFIED="1146186190926" TEXT="local trace minerals"/>
<node COLOR="#111111" CREATED="1146186191667" ID="Freemind_Link_606181874" MODIFIED="1146186202643" TEXT="regional geological resources"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182612517" FOLDED="true" ID="Freemind_Link_917640039" MODIFIED="1265958318949" POSITION="right" TEXT="Shelter &amp; Buildings">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146182620999" FOLDED="true" ID="Freemind_Link_971441745" MODIFIED="1197607775836" TEXT="construction materials">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146186217575" FOLDED="true" ID="Freemind_Link_1963125979" MODIFIED="1244915764871" TEXT="timber">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146186219648" ID="Freemind_Link_123472607" MODIFIED="1146186222592" TEXT="growers"/>
<node COLOR="#111111" CREATED="1146186222822" ID="Freemind_Link_15576420" MODIFIED="1146186226678" TEXT="suppliers"/>
<node COLOR="#111111" CREATED="1146186227008" ID="Freemind_Link_371691681" MODIFIED="1146186232616" TEXT="community timber plantations"/>
</node>
<node COLOR="#990000" CREATED="1146186239426" ID="Freemind_Link_1194591730" MODIFIED="1146186263921" TEXT="stone,gravel, &amp; earthen materials">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186269169" ID="Freemind_Link_951896045" MODIFIED="1146186282448" TEXT="plumbing, piping, drainage &amp; roofing">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186285622" FOLDED="true" ID="Freemind_Link_1932856949" MODIFIED="1244915764871" TEXT="bricks, concrete products">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146186302346" ID="Freemind_Link_46414575" MODIFIED="1146186306522" TEXT="tanks,"/>
<node COLOR="#111111" CREATED="1146186306793" ID="Freemind_Link_338475266" MODIFIED="1146186310618" TEXT="blocks"/>
</node>
<node COLOR="#990000" CREATED="1146186332079" ID="Freemind_Link_383641045" MODIFIED="1146186343215" TEXT="tile, surfaces and paints">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186343666" FOLDED="true" ID="Freemind_Link_1031170021" MODIFIED="1146186348262" TEXT="reference">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146186379427" ID="Freemind_Link_149724435" MODIFIED="1146186382141" TEXT="library"/>
<node COLOR="#111111" CREATED="1146186382382" ID="Freemind_Link_904927439" MODIFIED="1146186383713" TEXT="howto"/>
<node COLOR="#111111" CREATED="1146186384044" ID="Freemind_Link_1148052539" MODIFIED="1146186400818" TEXT="current state of housing needs"/>
<node COLOR="#111111" CREATED="1146186404844" ID="Freemind_Link_56996709" MODIFIED="1146186455907" TEXT="list of toxins et al"/>
</node>
<node COLOR="#990000" CREATED="1146187428960" ID="Freemind_Link_1206220990" MODIFIED="1146187444432" TEXT="reliable contractors &amp; builders">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182627278" FOLDED="true" ID="Freemind_Link_960671793" MODIFIED="1197607775841" TEXT="energy systems">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146186502174" ID="Freemind_Link_1255498359" MODIFIED="1146186539417" TEXT="conservation, efficiency, savings methods and materials">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186543073" ID="Freemind_Link_1426116638" MODIFIED="1146186550213" TEXT="hot water systems">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186551825" ID="Freemind_Link_89697551" MODIFIED="1146186558575" TEXT="space heating">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146186558875" ID="Freemind_Link_1848992396" MODIFIED="1146186573747" TEXT="house design options">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146187428960" ID="Freemind_Link_1449989823" MODIFIED="1146187444432" TEXT="reliable contractors &amp; builders">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182631063" FOLDED="true" ID="Freemind_Link_226745972" MODIFIED="1197607775842" TEXT="wastes &amp; recycling">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146187451692" ID="Freemind_Link_1138763160" MODIFIED="1146187462298" TEXT="sewage &amp; greywater">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146187463089" ID="Freemind_Link_566283606" MODIFIED="1146187470359" TEXT="compost systems &amp; organics">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146187472542" ID="Freemind_Link_1688084147" MODIFIED="1146187492051" TEXT="solid wastes disposal &amp; collection">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146187492932" ID="Freemind_Link_385162125" MODIFIED="1146187513591" TEXT="occupations based on waste recycling">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182638053" FOLDED="true" ID="Freemind_Link_334676921" MODIFIED="1265958318951" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Livelihoods support systems
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146182651963" FOLDED="true" ID="Freemind_Link_1128436876" MODIFIED="1197607775843" TEXT="community finance and recycling">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146187981134" ID="Freemind_Link_1934293757" MODIFIED="1146187984609" TEXT="barter and exchange">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146187985130" ID="Freemind_Link_1965404167" MODIFIED="1146187996256" TEXT="small business loans">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146187996536" ID="Freemind_Link_1066721824" MODIFIED="1146188010867" TEXT="community banking &amp; investments">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188016715" FOLDED="true" ID="Freemind_Link_1824179939" MODIFIED="1244915764877" TEXT="land access systems">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146188023955" ID="Freemind_Link_1813306571" MODIFIED="1146188026249" TEXT="common works"/>
<node COLOR="#111111" CREATED="1146188026489" ID="Freemind_Link_1078134193" MODIFIED="1146188028912" TEXT="leases"/>
<node COLOR="#111111" CREATED="1146188029183" ID="Freemind_Link_269807647" MODIFIED="1146188031857" TEXT="trusts"/>
</node>
<node COLOR="#990000" CREATED="1146188035272" ID="Freemind_Link_1437258371" MODIFIED="1146188042121" TEXT="legal and information services">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182661016" FOLDED="true" ID="Freemind_Link_351461703" MODIFIED="1197607775845" TEXT="livelihood support services">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146188045126" ID="Freemind_Link_720066332" MODIFIED="1146188056142" TEXT="small business service centers">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188056532" ID="Freemind_Link_1520352044" MODIFIED="1146188062331" TEXT="skill resource bank">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188064424" ID="Freemind_Link_1078123758" MODIFIED="1146188074708" TEXT="self-employment">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188074999" ID="Freemind_Link_862315633" MODIFIED="1146188079155" TEXT="training courses in the region">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182677130" FOLDED="true" ID="Freemind_Link_1484822530" MODIFIED="1248498934856">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      essential trades,&#160;manufacturing services&#160;and skills
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146188176264" ID="Freemind_Link_1366616360" MODIFIED="1146188187511" TEXT="clothing and cloth production">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188189153" ID="Freemind_Link_1258259138" MODIFIED="1146188197014" TEXT="footwear">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188197285" ID="Freemind_Link_529061846" MODIFIED="1146188200489" TEXT="leatherwork">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188202592" ID="Freemind_Link_1154398875" MODIFIED="1146188207910" TEXT="basketry and weaving">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188267986" ID="Freemind_Link_1993258965" MODIFIED="1146188274786" TEXT="functional pottery">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188275197" FOLDED="true" ID="Freemind_Link_678530894" MODIFIED="1146188281065" TEXT="metal work">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146188281325" ID="Freemind_Link_1453609016" MODIFIED="1146188284019" TEXT="steelwork"/>
<node COLOR="#111111" CREATED="1146188284320" ID="Freemind_Link_305381451" MODIFIED="1146188288486" TEXT="fitting and turning"/>
<node COLOR="#111111" CREATED="1146188288786" ID="Freemind_Link_91676946" MODIFIED="1146188292952" TEXT="smithng"/>
<node COLOR="#111111" CREATED="1146188293263" ID="Freemind_Link_584411693" MODIFIED="1146188295356" TEXT="casting"/>
<node COLOR="#111111" CREATED="1146188296387" ID="Freemind_Link_985354859" MODIFIED="1146188297819" TEXT="welding"/>
</node>
<node COLOR="#990000" CREATED="1146188304879" ID="Freemind_Link_473571132" MODIFIED="1146188314473" TEXT="engine &amp; engine repairs">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188316987" FOLDED="true" ID="Freemind_Link_1313458171" MODIFIED="1244915764877" TEXT="paper recycling &amp; manufacturing">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146188347230" ID="Freemind_Link_1585729086" MODIFIED="1146188361771" TEXT="book trades, printing and binding"/>
</node>
<node COLOR="#990000" CREATED="1146188365807" ID="Freemind_Link_1028682601" MODIFIED="1146188369502" TEXT="catering and cooking">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188370934" ID="Freemind_Link_1842782956" MODIFIED="1146188377924" TEXT="draughting and illustration services">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188378715" ID="Freemind_Link_926436349" MODIFIED="1146188384404" TEXT="soaps and cleaning materials">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182702065" FOLDED="true" ID="Freemind_Link_1452342962" MODIFIED="1248499065807" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      I.S., media services, communication &amp; research
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146182850929" FOLDED="true" ID="Freemind_Link_53303673" MODIFIED="1244915764885" TEXT="communications">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146188400547" FOLDED="true" ID="Freemind_Link_1822907206" MODIFIED="1244915764884" TEXT="regional radio">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146188410081" ID="Freemind_Link_1400711163" MODIFIED="1146188414297" TEXT="CB"/>
<node COLOR="#111111" CREATED="1146188414577" ID="Freemind_Link_1390855135" MODIFIED="1146188416059" TEXT="ham"/>
</node>
<node COLOR="#990000" CREATED="1146188420986" ID="Freemind_Link_1273624406" MODIFIED="1146188429569" TEXT="regional news">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188430009" FOLDED="true" ID="Freemind_Link_1969563155" MODIFIED="1244915764884" TEXT="audio-visual services">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146188471008" ID="Freemind_Link_1375090108" MODIFIED="1146188478729" TEXT="photography"/>
<node COLOR="#111111" CREATED="1146188479010" ID="Freemind_Link_506276294" MODIFIED="1146188483927" TEXT="television"/>
<node COLOR="#111111" CREATED="1146188484237" ID="Freemind_Link_998776177" MODIFIED="1146188485489" TEXT="film"/>
</node>
<node COLOR="#990000" CREATED="1146188441255" ID="Freemind_Link_1887816681" MODIFIED="1146188508222" TEXT="business and research communications">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188524525" ID="Freemind_Link_680585431" MODIFIED="1146188533658" TEXT="computer servicing and training">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188535451" ID="Freemind_Link_161404059" MODIFIED="1146188544163" TEXT="libraries and collections of data in the region">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188547708" ID="Freemind_Link_1348175932" MODIFIED="1146188549000" TEXT="maps">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188549391" ID="Freemind_Link_753912680" MODIFIED="1146188563942" TEXT="bioregional groups and contacts">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188564573" ID="Freemind_Link_1694924204" MODIFIED="1146188575759" TEXT="standard documents and data sheets ">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182726080" FOLDED="true" ID="Freemind_Link_98189415" MODIFIED="1265958318953" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Community and security
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146182873302" FOLDED="true" ID="Freemind_Link_1380917471" MODIFIED="1248498815752">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      housing and livestock security
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146188585303" ID="Freemind_Link_1939380521" MODIFIED="1146188587906" TEXT="house sitting">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188590160" ID="Freemind_Link_1609426363" MODIFIED="1146188596038" TEXT="neighborhood watch">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146188597300" ID="Freemind_Link_217031874" MODIFIED="1146188603018" TEXT="cattle and livestock watch">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146182918457" ID="Freemind_Link_788854059" MODIFIED="1197607775854" TEXT="Fire volunteers and reports">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146182942030" ID="Freemind_Link_1366910900" MODIFIED="1197607775855" TEXT="flood">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146182946948" ID="Freemind_Link_1516886398" MODIFIED="1197607775855" TEXT="bush, cliff, &amp; beach rescue services">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146182964763" ID="Freemind_Link_855307883" MODIFIED="1197607775856" TEXT="emergency communication systems">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182888534" FOLDED="true" ID="Freemind_Link_1247380600" MODIFIED="1265958318954" POSITION="right" TEXT="Social Life">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146182986484" ID="Freemind_Link_647294200" MODIFIED="1197607775857" TEXT="introduction services">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146182993174" ID="Freemind_Link_1607942696" MODIFIED="1197607775857" TEXT="think tanks">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146182996749" ID="Freemind_Link_1673285044" MODIFIED="1197607775858" TEXT="expeditions">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146183000725" ID="Freemind_Link_284423521" MODIFIED="1197607775858" TEXT="work groups">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182734172" FOLDED="true" ID="Freemind_Link_492432398" MODIFIED="1265958318955" POSITION="right" TEXT="Health Services">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146183010659" ID="Freemind_Link_1166792110" MODIFIED="1197607775859" TEXT="medical &amp; pharmaceutical services">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146183023307" ID="Freemind_Link_124204914" MODIFIED="1197607775860" TEXT="surgical &amp; hospitalisation services">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146183034744" ID="Freemind_Link_1448118138" MODIFIED="1248498834312">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      gynaecological, midwifery services, and home birth support
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146183086508" FOLDED="true" ID="Freemind_Link_785456583" MODIFIED="1197607775861" TEXT="regional profile of">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146183153374" ID="Freemind_Link_54664600" MODIFIED="1146183397325" TEXT="morbidity">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146183169848" ID="Freemind_Link_185709930" MODIFIED="1146183397325" TEXT="life expecancy">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146183186081" ID="Freemind_Link_1308878600" MODIFIED="1146183397325" TEXT="infant mortality">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146183194403" FOLDED="true" ID="Freemind_Link_924347467" MODIFIED="1244915764904" TEXT="health issues">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1146183205990" ID="Freemind_Link_481164423" MODIFIED="1146183397325" TEXT="accidents, injuries"/>
<node COLOR="#111111" CREATED="1146183235462" ID="Freemind_Link_1814087957" MODIFIED="1146183397325" TEXT="infectious diseases"/>
<node COLOR="#111111" CREATED="1146183243073" ID="Freemind_Link_1566917497" MODIFIED="1146183397325" TEXT="addictions &amp; drugs"/>
<node COLOR="#111111" CREATED="1146188662353" ID="Freemind_Link_1622826049" MODIFIED="1146188672908" TEXT="nutritional problems"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146182740561" FOLDED="true" ID="Freemind_Link_1011087255" MODIFIED="1265958318956" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Long term planning
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146183073850" ID="Freemind_Link_1582455536" MODIFIED="1197607775863" TEXT="seal level rising">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188835813" ID="Freemind_Link_711382400" MODIFIED="1197607775864" TEXT="ozone depletion">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188840209" ID="Freemind_Link_225683307" MODIFIED="1197607775864" TEXT="water pollution">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188853098" ID="Freemind_Link_84981063" MODIFIED="1248498847678">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      radioactives, chemcial and/or waste pollution
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188878134" ID="Freemind_Link_1864212076" MODIFIED="1197607775865" TEXT="financial collapse">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188891122" ID="Freemind_Link_1202599233" MODIFIED="1197607775866" TEXT="electrical shortages">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188902038" ID="Freemind_Link_140715099" MODIFIED="1197607775866" TEXT="liquid fuel shortages">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146188954013" ID="Freemind_Link_1794571778" MODIFIED="1197607775867" TEXT="food assuranencies">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146188994671" FOLDED="true" ID="Freemind_Link_1817288735" MODIFIED="1265958318957" POSITION="right" TEXT="Transport">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146188998056" FOLDED="true" ID="Freemind_Link_1959887132" MODIFIED="1197607775868" TEXT="barge">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146189004205" ID="Freemind_Link_204748617" MODIFIED="1146189005206" TEXT="river">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189005567" ID="Freemind_Link_1150120165" MODIFIED="1146189007710" TEXT="sea traffic">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1146189008942" ID="Freemind_Link_846582783" MODIFIED="1197607775868" TEXT="draught animal systems">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146189017524" ID="Freemind_Link_574982080" MODIFIED="1197607775869" TEXT="joint or group delivery">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146189027288" ID="Freemind_Link_648675455" MODIFIED="1197607775869" TEXT="local fuels">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146189034528" ID="Freemind_Link_612544254" MODIFIED="1197607775870" TEXT="innovation">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146189044363" ID="Freemind_Link_12452332" MODIFIED="1197607775870" TEXT="transporation routes, bikeways">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1146189051142" ID="Freemind_Link_1314107377" MODIFIED="1197607775871" TEXT="air and ultralight crafts, blimps">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1146189068117" FOLDED="true" ID="Freemind_Link_619295819" MODIFIED="1265958318958" POSITION="right" TEXT="maps">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1146189069158" FOLDED="true" ID="Freemind_Link_219845392" MODIFIED="1197607775872" TEXT="bioreigional maps">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1146189078532" ID="Freemind_Link_633175266" MODIFIED="1146189083178" TEXT="geological">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189083469" ID="Freemind_Link_1816374488" MODIFIED="1146189086934" TEXT="plant systems">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189087505" ID="Freemind_Link_1908810489" MODIFIED="1146189089357" TEXT="soils">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189089628" ID="Freemind_Link_1026945307" MODIFIED="1146189100393" TEXT="source and references to maps, suppliers">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189100704" ID="Freemind_Link_1827613266" MODIFIED="1146189107914" TEXT="regions &amp; parishes">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189108224" ID="Freemind_Link_1380887788" MODIFIED="1146189110237" TEXT="land titles">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189110518" ID="Freemind_Link_1334212467" MODIFIED="1146189114293" TEXT="access and roads">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189114544" ID="Freemind_Link_1223823877" MODIFIED="1146189122845" TEXT="reserves and easements">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1146189127072" ID="Freemind_Link_110809797" MODIFIED="1146189133050" TEXT="rivers and water supplies">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>

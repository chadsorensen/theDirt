// $Id: fckeditor.popup.js,v 1.2.2.1 2008/02/13 15:52:17 wwalc Exp $
function FCKeditor_OpenPopup( popupUrl )
{
	window.open( popupUrl, null, 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=1,dependent=yes' );
}

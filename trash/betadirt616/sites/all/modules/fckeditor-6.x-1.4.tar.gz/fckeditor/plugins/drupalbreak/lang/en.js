FCKLang.DrupalBreakTooltip = 'Insert Teaser Break' ;
FCKLang.DrupalBreakTitle = 'Teaser' ;

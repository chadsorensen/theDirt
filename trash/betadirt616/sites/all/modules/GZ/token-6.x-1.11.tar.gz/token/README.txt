$Id: README.txt,v 1.1 2006/12/31 01:41:50 eaton Exp $

Description
===========
Token module provides a centralized API for text substitution. Unless
you're installing another Drupal module that requires it, this software
is probably unnecessary.

Benefits
========
If you're a Drupal developer, check out API.txt for detailed instructions
on using the Token API. It allows every module to announce the placeholder
tokens they can handle, uses simple caching to prevent duplicated work in
a given page-view, and is pretty lightweight. It's nice. You'll like it.
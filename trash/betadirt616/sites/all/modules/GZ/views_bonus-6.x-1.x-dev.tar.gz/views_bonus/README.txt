// $Id: README.txt,v 1.11 2008/05/10 14:00:11 dmitrig01 Exp $

HEAD is not currently supported for the views_bonus module.
Instead, if you want the latest development version, please checkout 
the branch according that matches your version of Drupal.  Please note
that the 4.7 branch is barely maintained.

Drupal 5.x: DRUPAL-5
Drupal 4.7: DRUPAL-4-7

The HEAD branch will be used for the Drupal 6 of this module.
As this has not started, we are not currently supporting HEAD.

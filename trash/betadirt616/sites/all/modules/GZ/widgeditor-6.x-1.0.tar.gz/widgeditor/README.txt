About
-----

widgEditor( http://www.themaninblue.com/experiment/widgEditor/ ) is an easily installed, easily customizable WYSIWYG editor for simple content. It replaces node, comment and other specified textareas with an improved editing pane using JavaScript, therefore if you don't have JavaScript (or your browser doesn't support HTML editing) it degrades gracefully. 

Note that the module requires PHP 5.

Install
-----

 * Enable the module.
 * Set 'use widgEditor' permission on user access control setup.
 * By default widgEditor is loaded automatically for node and comment body fields.
 * Set default behaviour and textareas associated in the widgEditor settings at admin/settings/widgeditor.

Maintainer
-----
Gurpartap Singh <http://drupal.org/user/41470/contact>

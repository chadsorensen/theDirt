$Id: README.txt,v 1.1 2008/07/18 19:13:27 weitzman Exp $

og_notifications integrates OG with the notifications and messaging modules
family thereby enabling such features as group subscriptions, administrative
notifications etc.

The notifications and messaging modules extend beyond simple e-mail based
delivery systems and provide other avenues to contact recipients such as
private messages, simple alerts and even SMS.

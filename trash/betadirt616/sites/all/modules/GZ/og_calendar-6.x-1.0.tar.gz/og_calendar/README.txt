$Id: README.txt,v 1.2.2.1 2007/04/03 17:02:40 darrenoh Exp $

DESCRIPTION
-----------
This module provides each group with a calendar showing only the group's
events.

REQUIREMENTS
------------
- Requires the organic groups module.
- Requires the event module.

INSTALLATION
------------
- Enable the module from administer >> modules.

USAGE
-----
- Click on the "group calendar" link from either the group details block
  or on the event node itself.

CREDITS
-------
Authored by Angela Byron of CivicSpace Labs
Support provided by Chad Philips
Sponsored by Raven Brooks of BuyBlue.org

<div class="event-calendar"><div class="list-view"><?php print $variables['rows']; ?></div></div>

CHRISTMAS SNOW MODULE
------------------

Christmas Snow Module:
By: introfini
Mailto: introfini@gmail.com

Licensed under the GNU/GPL License

---------------------------------------------------------------------------------------------------------

Pre-Installation
-----------------

Due to variation in licensing, you will need to download the JavaScript code separately. Please download the file: http://www.schillmania.com/projects/snowstorm/snowstorm_20041121a.zip You will then need to copy the directory \image and the directory \script of this download into the \christmas_snow\ directory of the Christmas Snow. 

When copied, the directory should look like:

\christmas_snow\christmas_snow.module
\christmas_snow\image\snow\0.gif
\christmas_snow\image\snow\0.png
\christmas_snow\image\snow\1.gif
\christmas_snow\image\snow\1.png
\christmas_snow\image\snow\2.gif
\christmas_snow\image\snow\2.png
\christmas_snow\image\snow\3.gif
\christmas_snow\image\snow\3.png
\christmas_snow\image\snow\4.gif
\christmas_snow\image\snow\4.png
\christmas_snow\image\snow\5.gif
\christmas_snow\image\snow\5.png
\christmas_snow\image\snow\none.gif
\christmas_snow\script\snowstorm.js


Installation
------------
1. Copy christmas_snow folder to modules directory
2. At admin/modules enable the module
3. It's done

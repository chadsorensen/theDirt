<div>
 <?php print $map; ?>
</div>
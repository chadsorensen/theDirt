<?php
// $Id: views-bonus-panels-twocol.tpl.php,v 1.1 2009/01/03 04:50:45 neclimdul Exp $
/**
 * @file
 * Two column rendering template.
 */

panels_load_include('display-render');
print panels_print_layout($panel_name, $content);

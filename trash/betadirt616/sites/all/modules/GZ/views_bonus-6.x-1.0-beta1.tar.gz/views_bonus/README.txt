// $Id: README.txt,v 1.12 2009/01/06 18:40:25 neclimdul Exp $

This group of modules contains plugins, default views and other code that
builds on top of views but might not fit anywhere else.

Because of the changes to Views 2 in Drupal 6, many modules may be drastically
different and other features have been pulled into the core views features. As
such the upgrade path might not always be direct. Most features have been
translated from earlier releases. You can follow the support chain to solve
any upgrade issues that are completly broken.

Drupal releases and their branches.
Drupal 6.x-1: HEAD
Drupal 5.x-1: DRUPAL-5
Drupal 4.7-1: DRUPAL-4-7

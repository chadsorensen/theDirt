YUI:
-----
http://developer.yahoo.com/yui
http://developer.yahoo.com/yui/editor/


Installation:
-----
There is a link to a video that shows how to install the module
on the project homepage: http://www.drupal.org/project/yui_editor

Author:
-----
Abdelrahman Ghareeb <abdelrahman at slashproc dot net>
Jeff Decker <jeff at jeffcd dot com>

Sponsor:
-----
This module is sponsored by OpenCraft http://www.open-craft.com

/* $Id: README.txt,v 1.3 2008/10/29 17:39:41 bdragon Exp $ */

Third party code.
Place downloaded third party code in this folder if instructed to by GMap.

(todo: document better)

clusterer2.js
------------
Marker clusterer addon by Jef Poskanzer
This was the original "marker clustering" solution for viewing large sets of markers without
loss of speed.
Website: http://www.acme.com/javascript/#Clusterer
Save the results of the [View source code.] link.
Tested version at: http://www.acme.com/javascript/Clusterer2.js

wms-gs-1_0_1.js
---------------
WMS support library.
The specifics are still up in the air at this point.

http://geoserver.org/display/GEOSDOC/Google+Maps
http://chignik.berkeley.edu/google/wms236.js
http://dist.codehaus.org/geoserver/gmaps-geoserver_scripts/wms-gs-1_0_0.js
http://dist.codehaus.org/geoserver/gmaps-geoserver_scripts/wms-gs-1_0_1.js
// $Id: README.txt,v 1.1.4.2 2009/07/09 21:00:51 aaron Exp $

README for Embedded Inline Media

This module provides the ability to parse URLs of third party media providers
from a node or comment content, and display the media appropriately.

Experimental; currently only works for video.
